.. include:: replace.txt

Applications
------------

*Placeholder chapter*
